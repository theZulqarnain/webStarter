module.exports ={
    googleClientID      :       '672436521-sq9avh0vk0ik0ioellf6i8davh2nehho.apps.googleusercontent.com',
    googleClientSecret  :       'XT4oUGt-1P4NvHBtrYbXjqde',
    cookieKey           :        'abdullaZulqarnain',
    facebookClientID    :       '847725942084636',
    facebookClientSecret:       'a9cbc02fe70c74aee9e52e237bebc853',
    githubClientID      :       '0eb460568785196970d7',
    githubClientSecret  :       '29a6da4bd98a8e848582aa6fefad3ab8217ea6f4',
    mysql_pwd           :       'admin',
    mysql_DB            :       'webstarter',
    mysql_users_tbl     :       'users'
}